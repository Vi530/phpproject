<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<style>
		/* Style for the container div */
.col-sm-12 {
    width: 100%;
    padding: 10px;
    text-align: center;
    background-color: #f4f4f4; /* Light background color */
}

/* Style for the back-link paragraph */
.back-link {
    font-size: 18px;
    color: white; /* Blue text color */
    font-family: Arial, sans-serif; /* Set the font */
    text-decoration: none; /* Remove underline */
    padding: 10px;
    background-color: #007BFF; /* Light gray background */
    border-radius: 5px; /* Rounded corners */
    display: inline-block; /* Allow padding and background to fit content */
   
	    width: 100%;
}

.back-link:hover {
    color: #fff; /* White color on hover */
    background-color: #007BFF; /* Blue background on hover */
    cursor: pointer; /* Change cursor to indicate interactivity */
}

	</style>
</head>
<body>
<div class="col-sm-12">
    <p class="back-link">Daily Expense Tracker@lucky</p>
</div>

</body>
</html>