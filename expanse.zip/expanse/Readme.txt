
1. Download the  zip file
2. Extract the file and copy expance folder
and hit localhost/expance_tacker in ur url

************Credential for user panel  OR you can register your self ************************
Username: lakkhichandra3072001@gmail.com
Password:Lucky@12345

